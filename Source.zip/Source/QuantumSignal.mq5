//+------------------------------------------------------------------+
//|                                                QuantumSignal.mq5 |
//|                        Quantum Signal MT5                        |
//+------------------------------------------------------------------+
#property copyright "Quantum Signal Project"
#property version   "1.000"
#property strict

#property indicator_chart_window
#property indicator_buffers 1
#property indicator_plots   1

#property indicator_label1  "Dummy"
#property indicator_type1   DRAW_NONE
#property indicator_color1  clrNONE

#include "Include/Dashboard.mqh"
#include "Include/ObjectManager.mqh"
#include "Include/Engine/EMAEngine.mqh"
#include "Include/Engine/TrendEngine.mqh"

//------------------------------------------------------------------
// Indicator Buffer
//------------------------------------------------------------------
double DummyBuffer[];

//------------------------------------------------------------------
// Global Objects
//------------------------------------------------------------------
CDashboard Dashboard;
CObjectManager Objects;
CEMAEngine EMA;
CTrendEngine Trend;

//+------------------------------------------------------------------+
//| Custom indicator initialization                                  |
//+------------------------------------------------------------------+
int OnInit()
{
   SetIndexBuffer(0, DummyBuffer, INDICATOR_DATA);

   Print("==========================================");
   Print(" Quantum Signal MT5");
   Print(" Version : 1.000");
   Print(" Status  : Initializing...");
   Print("==========================================");

   Objects.SetPrefix("QS_");

   if(!Dashboard.Create())
   {
      Print("Dashboard Initialize Failed");
      return(INIT_FAILED);
   }

   if(!EMA.Initialize())
   {
      Print("EMA Engine Initialize Failed");
      return(INIT_FAILED);
   }

   Dashboard.SetStatus("READY");

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Custom indicator deinitialization                                |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EMA.Release();

   Dashboard.Destroy();
   Objects.DeleteAll();
}

//+------------------------------------------------------------------+
//| Custom indicator calculation                                     |
//+------------------------------------------------------------------+
int OnCalculate(
   const int rates_total,
   const int prev_calculated,
   const datetime &time[],
   const double &open[],
   const double &high[],
   const double &low[],
   const double &close[],
   const long &tick_volume[],
   const long &volume[],
   const int &spread[]
)
{
   double ema20 = 0.0;
   double ema50 = 0.0;
   double ema200 = 0.0;

   if(
      EMA.EMA20(ema20) &&
      EMA.EMA50(ema50) &&
      EMA.EMA200(ema200)
   )
   {
      Trend.Calculate(ema20, ema50, ema200);
   }

   Dashboard.Update();

   return(rates_total);
}
//+------------------------------------------------------------------+